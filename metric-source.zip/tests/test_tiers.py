"""Which model tier each pass runs on.

The tiers exist because the work differs, not to economise for its own sake. Mapping free text
onto a closed vocabulary is classification; reading sixty pages and justifying a verdict is not,
and giving the first the second's budget makes it slower without making it better.

These tests pin the assignment. The failure they guard against is quiet in both directions: a
judgement pass silently demoted to a small model produces plausible output that is worse in ways
nobody notices, and a mechanical pass left on the large one costs time on every run forever.
"""
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from scenario_generator.core.models import Decision, IntakeData, Persona, State, Tool
from scenario_generator.core.probes import build_probes
from scenario_generator.llm import config
from scenario_generator.llm.conversation_mapping import ConversationMapper
from scenario_generator.llm.materiality import MaterialityAssessor
from scenario_generator.llm.reviewer import ScenarioReviewer
from scenario_generator.llm.writer import ScenarioWriter

_INTAKE = IntakeData(
    use_case={"Use case name": "Test", "Business objective": "Objective"},
    personas=[Persona("P1", "Default user", [], True)],
    capabilities=[],
    decisions=[Decision("DEC-01", "Auth", "CAP-01", "", ["Pass"])],
    states=[State("S-00", "Start", "Start", ["DEC-01"], False)],
    tools=[Tool("Filing API", "CAP-01", True)],
)


class _Recorder:
    """Stands in for the gateway and remembers which tier each call asked for."""

    def __init__(self, reply="{}"):
        self.reply = reply
        self.tiers = []

    def __call__(self, system, user, tier=None, max_tokens=None, reasoning_effort=None,
                 model=None, **kwargs):
        self.tiers.append(tier)
        return self.reply


class TestTierDefinitions(unittest.TestCase):
    def test_the_tiers_are_ordered_by_how_much_room_the_work_needs(self):
        self.assertGreater(config.JUDGEMENT.max_tokens, config.MATERIALITY.max_tokens)
        self.assertGreaterEqual(config.MATERIALITY.max_tokens, config.STANDARD.max_tokens)

    def test_only_the_judgement_tier_reasons_at_length(self):
        self.assertEqual(config.JUDGEMENT.reasoning_effort, "high")
        self.assertEqual(config.STANDARD.reasoning_effort, "minimal")

    def test_every_tier_falls_back_to_the_main_model(self):
        """Nothing changes until a smaller model is configured, which matters where a new model
        has to clear an approval before it can be used."""
        for tier in (config.JUDGEMENT, config.MATERIALITY, config.STANDARD):
            self.assertTrue(tier.model)

    def test_every_tier_a_stage_can_ask_for_actually_exists(self):
        """A tier nothing runs on is a knob documented in the README that changes nothing."""
        named = {config.JUDGEMENT.name, config.MATERIALITY.name, config.STANDARD.name}
        self.assertEqual(named, {"judgement", "materiality", "standard"})

    def test_materiality_retries_less_than_the_default(self):
        """Every chunk of the scenario space hits this tier at once, so a busy gateway means several
        simultaneous retries rather than one -- this tier is given a shorter ladder for that."""
        self.assertLess(config.MATERIALITY.max_attempts, config.DEFAULT_MAX_ATTEMPTS)
        self.assertEqual(config.JUDGEMENT.max_attempts, config.DEFAULT_MAX_ATTEMPTS)

    def test_the_corpus_limit_leaves_room_for_the_prompt_and_the_reply(self):
        """Four characters to a token, against a million-token input window."""
        self.assertLess(config.max_corpus_chars() / 4, 1_000_000)


def _same_settings(tier, base) -> bool:
    """Same model, budget, effort and retry ladder as ``base``.

    Not identity and not full equality: every call site runs through :func:`config.stage_tier`,
    which always returns a freshly built ``Tier`` named for its own call site (e.g.
    ``"judgement:reviewer_propose"``) even where nothing overrides it -- the name is what makes an
    override visible in a log line. What these tests guard is the substance of which tier a pass
    runs on, which is every field but the name.
    """
    return (tier.model == base.model and tier.max_tokens == base.max_tokens
            and tier.reasoning_effort == base.reasoning_effort
            and tier.max_attempts == base.max_attempts)


class TestStageOverrideCascade(unittest.TestCase):
    """config.stage_tier / config.stage_batch_size: stage, then tier, then master.

    Nothing here is used by a real pass -- these pin the cascade mechanism itself, independent of
    which stage key a given pass happens to use, so the guarantee stays checked even if a call
    site's key is renamed.
    """

    def test_a_stage_with_no_override_matches_its_tier_exactly(self):
        tier = config.stage_tier("A_STAGE_NOBODY_OVERRIDES", config.JUDGEMENT)
        self.assertEqual(tier.model, config.JUDGEMENT.model)
        self.assertEqual(tier.max_tokens, config.JUDGEMENT.max_tokens)
        self.assertEqual(tier.reasoning_effort, config.JUDGEMENT.reasoning_effort)
        self.assertEqual(tier.max_attempts, config.JUDGEMENT.max_attempts)
        self.assertEqual(tier.temperature, config.JUDGEMENT.temperature)

    def test_a_stage_override_wins_over_its_tier(self):
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_MODEL_ID": "tiny-model"}):
            tier = config.stage_tier("TEST_STAGE", config.JUDGEMENT)
        self.assertEqual(tier.model, "tiny-model")

    def test_overriding_one_field_leaves_the_rest_on_the_tier(self):
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_TEMPERATURE": "0.9"}):
            tier = config.stage_tier("TEST_STAGE", config.MATERIALITY)
        self.assertEqual(tier.temperature, 0.9)
        self.assertEqual(tier.model, config.MATERIALITY.model)
        self.assertEqual(tier.max_tokens, config.MATERIALITY.max_tokens)
        self.assertEqual(tier.max_attempts, config.MATERIALITY.max_attempts)

    def test_an_override_on_one_stage_does_not_leak_into_another(self):
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_MODEL_ID": "tiny-model"}):
            other = config.stage_tier("A_DIFFERENT_STAGE", config.JUDGEMENT)
        self.assertEqual(other.model, config.JUDGEMENT.model)

    def test_batch_size_falls_back_to_the_default_unset(self):
        self.assertEqual(config.stage_batch_size("A_STAGE_NOBODY_OVERRIDES", 6), 6)

    def test_batch_size_override_wins(self):
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_BATCH_SIZE": "3"}):
            self.assertEqual(config.stage_batch_size("TEST_STAGE", 6), 3)

    def test_concurrency_falls_back_to_the_global_cap_unset(self):
        self.assertEqual(config.stage_concurrency("A_STAGE_NOBODY_OVERRIDES"), config.MAX_CONCURRENCY)

    def test_concurrency_falls_back_to_a_given_default_unset(self):
        self.assertEqual(config.stage_concurrency("A_STAGE_NOBODY_OVERRIDES", default=2), 2)

    def test_concurrency_override_wins_over_both(self):
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_CONCURRENCY": "9"}):
            self.assertEqual(config.stage_concurrency("TEST_STAGE", default=2), 9)

    def test_concurrency_and_batch_size_are_independent_knobs(self):
        """Batch size is rows per call; concurrency is calls in flight -- setting one must not
        move the other."""
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_BATCH_SIZE": "3"}):
            self.assertEqual(config.stage_concurrency("TEST_STAGE"), config.MAX_CONCURRENCY)
        with mock.patch.dict(os.environ, {"LLM_STAGE_TEST_STAGE_CONCURRENCY": "9"}):
            self.assertEqual(config.stage_batch_size("TEST_STAGE", 6), 6)

    def test_tier_level_temperature_override_is_read_by_the_gateway(self):
        """A tier that sets its own temperature is what chat_model actually bills for.

        gateway._generation_parameters has to read tier.temperature rather than falling straight
        through to the global default, or a per-tier setting is accepted and then ignored.
        """
        from scenario_generator.llm.gateway import _generation_parameters

        with mock.patch.dict(os.environ, {"LLM_JUDGEMENT_TEMPERATURE": "0.9"}):
            tier = config._tier("judgement", "LLM_JUDGEMENT", 65_536, "high")
        parameters = _generation_parameters(tier, None, None, None)
        self.assertEqual(parameters["temperature"], 0.9)


class TestSettingsCascade(unittest.TestCase):
    """Environment, then tuning.yml, then the built-in default -- in that order.

    The split exists so a shared, reviewable file can hold how the work is run while .env holds
    only what is yours. What must not break is either end of it: a machine that overrides one
    setting locally, and a checkout with no tuning file at all.
    """

    def setUp(self):
        # Pointed by the environment, the way a person would point it: the module holds no
        # assignable copy of the path, so there is nothing to patch that the reader consults.
        self._env = mock.patch.dict(os.environ, {}, clear=False)
        self._env.start()
        config.reload_tuning()

    def tearDown(self):
        self._env.stop()
        config.reload_tuning()

    def _with_tuning(self, body: str) -> None:
        path = Path(tempfile.mkdtemp()) / "tuning.yml"
        path.write_text(body, encoding="utf-8")
        os.environ["TUNING_PATH"] = str(path)
        config.reload_tuning()

    def test_the_tuning_file_supplies_a_value_the_environment_does_not(self):
        self._with_tuning("stages:\n  writer:\n    batch_size: 4\n")
        self.assertEqual(config.stage_batch_size("WRITER", 8), 4)

    def test_the_environment_still_wins_over_the_file(self):
        self._with_tuning("stages:\n  writer:\n    batch_size: 4\n")
        with mock.patch.dict(os.environ, {"LLM_STAGE_WRITER_BATCH_SIZE": "9"}):
            self.assertEqual(config.stage_batch_size("WRITER", 8), 9)

    def test_no_tuning_file_falls_through_to_the_built_in_default(self):
        os.environ["TUNING_PATH"] = str(Path(tempfile.mkdtemp()) / "absent.yml")
        config.reload_tuning()
        self.assertEqual(config.stage_batch_size("WRITER", 8), 8)

    def test_an_unreadable_tuning_file_stops_the_run_rather_than_defaulting(self):
        """Continuing on defaults is the worse failure, and the one that actually costs something.

        A file that cannot be parsed is a mistake made seconds ago and fixable in seconds. Ignoring
        it reverts every value it was setting -- the model each stage calls, the batch sizes, the
        budgets -- and the run proceeds and produces plausible output, so the mistake surfaces as a
        scenario space that is subtly not the one that was asked for. See
        tests/test_tuning_file_is_enforced.py for the whole of this behaviour.
        """
        self._with_tuning("{{{ not yaml at all")
        with self.assertRaises(config.BrokenTuningFile):
            config.stage_batch_size("WRITER", 8)

    def test_a_value_of_the_wrong_type_falls_back_rather_than_raising(self):
        self._with_tuning("stages:\n  writer:\n    batch_size: not-a-number\n")
        self.assertEqual(config.stage_batch_size("WRITER", 8), 8)

    def test_a_list_setting_reads_from_yaml_as_a_list(self):
        """Comma-separated in the environment, a real list in YAML -- both arrive as a list."""
        self.assertEqual(config._csv(["American Express", "New York"]),
                         ["American Express", "New York"])
        self.assertEqual(config._csv("American Express,New York"),
                         ["American Express", "New York"])

    def test_thresholds_read_from_yaml_as_a_mapping(self):
        self.assertEqual(config._thresholds({"secondary_pii_email": 0.7}),
                         {"secondary_pii_email": {"score": 0.7}})


class TestWhichPassUsesWhichTier(unittest.TestCase):
    def test_the_review_pass_reasons(self):
        recorder = _Recorder('{"proposals": []}')
        ScenarioReviewer(complete=recorder, batch_size=4).review(
            build_probes(_INTAKE)[:4], _INTAKE)
        self.assertTrue(recorder.tiers)
        self.assertTrue(all(_same_settings(t, config.JUDGEMENT) for t in recorder.tiers))

    def test_the_materiality_pass_runs_on_its_own_tier(self):
        recorder = _Recorder()
        MaterialityAssessor(complete=recorder).assess(build_probes(_INTAKE)[:4], _INTAKE)
        self.assertTrue(recorder.tiers)
        self.assertTrue(all(_same_settings(t, config.MATERIALITY) for t in recorder.tiers))

    def test_writing_scenario_text_stays_on_the_standard_tier(self):
        """Mechanical, but the model owner reads it, so not the cheapest model."""
        recorder = _Recorder()
        ScenarioWriter(complete=recorder).write(build_probes(_INTAKE)[:4], _INTAKE)
        self.assertTrue(recorder.tiers)
        self.assertTrue(all(_same_settings(t, config.STANDARD) for t in recorder.tiers))

    def test_mapping_their_conversations_runs_on_the_judgement_tier(self):
        """Deciding which of several overlapping routes a transcript actually ends on is the
        hardest judgement in the pipeline, and getting it wrong reports coverage that is not
        there -- so it gets the strongest tier rather than the cheapest."""
        from scenario_generator.core.models import ScenarioRow
        from scenario_generator.ingest.conversations import Conversation, Turn

        recorder = _Recorder()
        ConversationMapper(complete=recorder).map(
            [Conversation(id="C1", turns=[Turn("user", "I want to dispute a charge here")])],
            [ScenarioRow(id="SC-001", path_str="DEC-01=Pass", category="Happy path",
                               materiality="High", capabilities=[], persona_id="P1",
                               signature=())],
            _INTAKE)
        self.assertTrue(recorder.tiers)
        self.assertTrue(all(_same_settings(t, config.JUDGEMENT) for t in recorder.tiers))


if __name__ == "__main__":
    unittest.main()
